import requests
from bs4 import BeautifulSoup
import re
import mysql.connector
from sklearn.tree import DecisionTreeRegressor
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer

cnx = mysql.connector.connect(user="root", password="1234", host="127.0.0.1", database="finalproject")
cursor = cnx.cursor()

pattern1 = r'\b\w+\b'
pattern2 = r'^(\d+)'
pattern3 = r',\s*([A-Z]{2})$'
pattern4 = r'\d+'

cursor.execute("SHOW TABLES LIKE 'cars'")
result = cursor.fetchone()

if not result:
    query = """CREATE TABLE IF NOT EXISTS cars (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(20),
        yearmake VARCHAR(4),
        kilometer VARCHAR(10),
        city VARCHAR(2),
        price VARCHAR(7)
    )"""
    cursor.execute(query)

    for page_number in range(2, 50):
        url = f"https://www.truecar.com/used-cars-for-sale/listings/?page={page_number}"
        response = requests.get(url)
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser')
            yearmake_name = soup.find_all('div', class_='w-full truncate font-bold', attrs={'data-test': 'vehicleCardConditionYearMake'})
            city_text = soup.find_all('div', class_='min-h-[18px]')
            prices = soup.find_all('span', class_='truncate', attrs={'data-test': 'vehicleCardPriceLabelAmount'})
            kilometer_list = soup.find_all('div', class_='flex items-center truncate text-xs', attrs={'data-test': 'vehicleMileage'})

            for i in range(len(prices)):
                yearmake_name_list = re.findall(pattern1, yearmake_name[i].text.strip())
                yearmake = yearmake_name_list[1]
                name = yearmake_name_list[2]
                match = re.search(pattern2, kilometer_list[i].text.strip())
                kilometer = match.group(1)
                match = re.search(pattern3, city_text[i].text.strip())
                city = match.group(1)
                matches = re.findall(pattern4, prices[i].text.strip())
                price = ''.join(matches)
                query = "INSERT INTO cars (name, yearmake, kilometer, city, price) VALUES (%s, %s, %s, %s, %s)"
                cursor.execute(query, (name, yearmake, kilometer, city, price))
                cnx.commit()

    cursor.close()
    cnx.close()

cnx = mysql.connector.connect(user="root", password="1234", host="127.0.0.1", database="finalproject")
cursor = cnx.cursor()

x = []
y = []

query = "SELECT name, yearmake, kilometer, city, price FROM cars"
cursor.execute(query)
results = cursor.fetchall()

for row in results:
    name = row[0]
    yearmake = row[1]
    kilometer = row[2]
    city = row[3]
    price = row[4]

    x.append([name, int(yearmake), int(kilometer), city])
    y.append(int(price))

cursor.close()
cnx.close()

ct = ColumnTransformer(transformers=[('encoder', OneHotEncoder(), [0, 3])], remainder='passthrough')
x = ct.fit_transform(x)

clf = DecisionTreeRegressor()
clf = clf.fit(x, y)

new_data = [['Ford', 2015, 200, 'FL'],
            ['Volvo', 2015, 200, 'FL'],
            ['Aston', 2014, 36, 'GA'],
            ['Toyota', 2015, 200, 'NY']]

new_data_transformed = ct.transform(new_data)

answer = clf.predict(new_data_transformed)
print(answer)
