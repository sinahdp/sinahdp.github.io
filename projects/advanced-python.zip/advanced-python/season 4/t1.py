import re
str = input()
pattern = r'^[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[a-zA-Z]+$'
result = re.match(pattern,str)

if(result == None) :
    print("WRONG")
else :
    print("OK")