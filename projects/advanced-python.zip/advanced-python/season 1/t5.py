string = input()
list_words = string.split()
index = 0
ghabli = " "
result = None
for i in list_words : 
    if(ord("Z") >= ord(i[0]) >= ord("A")):
        if (index == 0 or ghabli[-1] == "."):
            index += 1
            ghabli = i
        else:
            index += 1
            if(i[-1]=="." or i[-1]==","):
                result = i[:-1]
                print(f"{index}:{result}")
            else:
                result = i
                print(f"{index}:{result}")
    else:
        index += 1
    ghabli = i
if(result == None):
    print("None")