count = int(input())
list = []
name_dict = {}
for i in range(count):
    arr= input()
    list = arr.split(".")
    name = list[1][0].upper() + list[1][1:].lower()
    name_dict[name]={"fn" : list[0] , "lang" : list[2]}

sorted_dict = sorted(name_dict.items(),key = lambda x: (x[1]["fn"],x[0]))
for (i,j) in sorted_dict:
    print(f"{j['fn']} {i} {j['lang']}")