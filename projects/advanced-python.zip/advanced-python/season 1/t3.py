count = int(input())
zhanr = {
    "Horror" : 0 ,
    "Romance" : 0 ,
    "Comedy" : 0 ,
    "History" : 0 ,
    "Adventure" : 0 ,
    "Action": 0
}
for i in range(count):
    arr=input()
    list = arr.split()
    for i in zhanr:
        if(list[1]== i):
            zhanr[i] += 1
        if(list[2]== i):
            zhanr[i] += 1
        if(list[3]== i):
            zhanr[i] += 1
sorted_zhanr = sorted(zhanr.items(), key=lambda x: (-x[1], x[0]))
for (i,j) in sorted_zhanr:
    print(f"{i} : {j}")