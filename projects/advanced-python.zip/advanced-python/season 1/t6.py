count = int(input())
translation_dict = {}
for i in range(count):
    word , english , french , german = input().split()
    translation_dict[word] = {
        "English" : english ,
        "French" : french ,
        "German" : german
    }
    
sentence = input().split()
translated_sentence = []

for word in sentence:
    for dict_word, translations in translation_dict.items():
        if word in translations.values():
            translated_sentence.append(dict_word)
            break
    else:
        translated_sentence.append(word)


print(" ".join(translated_sentence))