arr = []
max_counter = -1000
max_number = -1000
for i in range(10):
    arr.append(int(input()))
def myfunc1(num):
    for i in range(2,int((num)**0.5)+1):
        if(num % i == 0):
            return False
    else:
        return True
def myfunc2(num):
    global max_counter, max_number
    counter = 0
    for i in range(2,int(num/2 + 1)):
        if(myfunc1(i) and num % i == 0):
            counter += 1
    if(max_counter < counter):
        max_counter = counter
        max_number = num
    elif (max_counter == counter and num > max_number):
        max_number = num
for i in range(10):
    myfunc2(arr[i])
print(str(max_number) + " " + str(max_counter))
