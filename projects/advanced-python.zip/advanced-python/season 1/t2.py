arr = ""
list = []
teams = {
    "Spain" : {"points": 0, "wins": 0,"loses": 0,"draws": 0, "goals_for": 0, "goals_against": 0} ,
    "Iran" : {"points": 0, "wins": 0,"loses": 0,"draws": 0, "goals_for": 0, "goals_against": 0} ,
    "Portugal " : {"points": 0, "wins": 0,"loses": 0,"draws": 0, "goals_for": 0, "goals_against": 0} ,
    "Morocco " : {"points": 0, "wins": 0,"loses": 0,"draws": 0, "goals_for": 0, "goals_against": 0}
}

results = [
    ["Iran","Spain",None,None],
    ["Iran", "Portugal ", None, None],
    ["Iran", "Morocco ", None, None],
    ["Spain", "Portugal ", None, None],
    ["Spain", "Morocco ", None, None],
    ["Portugal ", "Morocco ", None, None],
]
for i in range(6):
    arr = input()
    list = arr.split("-")
    results[i][2]=int(list[0])
    results[i][3]=int(list[1])

# محاسبه امتیازات و تفاضل گل تیم‌ها
for result in results:
    team1, team2, score1, score2 = result
    teams[team1]["goals_for"] += score1
    teams[team1]["goals_against"] += score2
    teams[team2]["goals_for"] += score2
    teams[team2]["goals_against"] += score1
    if score1 > score2:
        teams[team1]["wins"] += 1
        teams[team1]["points"] += 3
        teams[team2]["loses"] += 1
    elif score1 < score2:
        teams[team2]["wins"] += 1
        teams[team2]["points"] += 3
        teams[team1]["loses"] += 1
    else:
        teams[team1]["points"] += 1
        teams[team2]["points"] += 1
        teams[team1]["draws"] += 1
        teams[team2]["draws"] += 1


sorted_teams = sorted(teams.items(), key=lambda x: (-x[1]["points"], -x[1]["wins"], x[0]))
for i,(team,stats) in enumerate(sorted_teams):
    print(f"{team}  wins:{stats['wins']} , loses:{stats['loses']} , draws:{stats['draws']} , goal difference:{stats['goals_for']-stats['goals_against']} , points:{stats['points']}")
