import datetime
birth_date_str = input()
date_list = list(map(int, birth_date_str.split("/")))
day, month, year = date_list[2], date_list[1], date_list[0]
if day < 1 or day > 31 or month < 1 or month > 12:
    print("WRONG")
else :
    today = datetime.date.today()
    age = today.year - year 
    print(age)
