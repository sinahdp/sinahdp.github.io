class Student:
    def __init__(self, age, height, weight):
        self.age = age
        self.height = height
        self.weight = weight

class SchoolClass:
    def __init__(self):
        self.students = []

    def add_student(self, student):
        self.students.append(student)

    def average_age(self):
        return sum(student.age for student in self.students) / len(self.students)

    def average_height(self):
        return sum(student.height for student in self.students) / len(self.students)

    def average_weight(self):
        return sum(student.weight for student in self.students) / len(self.students)

def main():
    class_A = SchoolClass()
    class_B = SchoolClass()

    # Read number of students in class A
    n_A = int(input())
    ages_A = list(map(int, input().split()))
    heights_A = list(map(int, input().split()))
    weights_A = list(map(int, input().split()))
    
    for i in range(n_A):
        student = Student(ages_A[i], heights_A[i], weights_A[i])
        class_A.add_student(student)

    # Read number of students in class B
    n_B = int(input())
    ages_B = list(map(int, input().split()))
    heights_B = list(map(int, input().split()))
    weights_B = list(map(int, input().split()))
    
    for i in range(n_B):
        student = Student(ages_B[i], heights_B[i], weights_B[i])
        class_B.add_student(student)

    # Calculate averages for class A
    avg_age_A = class_A.average_age()
    avg_height_A = class_A.average_height()
    avg_weight_A = class_A.average_weight()

    # Calculate averages for class B
    avg_age_B = class_B.average_age()
    avg_height_B = class_B.average_height()
    avg_weight_B = class_B.average_weight()

    # Print averages
    print(f"{avg_age_A}")
    print(f"{avg_height_A}")
    print(f"{avg_weight_A}")
    print(f"{avg_age_B}")
    print(f"{avg_height_B}")
    print(f"{avg_weight_B}")

    # Compare classes
    if avg_height_A > avg_height_B:
        print("A")
    elif avg_height_B > avg_height_A:
        print("B")
    else:  # avg_height_A == avg_height_B
        if avg_weight_A < avg_weight_B:
            print("A")
        elif avg_weight_B < avg_weight_A:
            print("B")
        else:
            print("Same")

main()
