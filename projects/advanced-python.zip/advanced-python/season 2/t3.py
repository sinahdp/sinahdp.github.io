import random

class Human:
    def __init__(self, name):
        self.name = name

class Footballer(Human):
    def __init__(self, name):
        super().__init__(name)

player_names = ["Hossein", "Maziar", "Akbar", "Nima", "Mahdi", "Farhad", "Mohammad", "Khashayar", "Milad", 
                "Mostafa", "Amin", "Saeed", "Pouya", "Pouria", "Reza", "Ali", "Behzad", "Soheil", 
                "Behrooz", "Shahrooz", "Saman", "Mohsen"]

players = [Footballer(name) for name in player_names]

random.shuffle(players)
team_A = players[:11]
team_B = players[11:]

print("Team A:")
for player in team_A:
    print(player.name)

print("\nTeam B:")
for player in team_B:
    print(player.name)
