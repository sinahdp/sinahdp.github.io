from decouple import config
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackContext, ConversationHandler 
import logging
import random

Token = config("Token")

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

CHAT_ALIAS, ALIAS_CONFIRMATION = range(2)
user_aliases = {}
chat_participants = set()
online_users = {}  

def get_join_keyboard():
    keyboard = [[KeyboardButton("/join")]]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def get_confirm_keyboard():
    return ReplyKeyboardMarkup([["تایید", "تغییر نام"]], one_time_keyboard=True, resize_keyboard=True)

def get_chat_keyboard():
    keyboard = [[KeyboardButton("/leave")],[KeyboardButton("/show_online_users")]]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

async def start(update: Update, context: CallbackContext) -> None:
    user_id = update.message.from_user.id
    if user_id in chat_participants:
        await update.message.reply_text('شما هم‌اکنون در چت حضور دارید.', reply_markup=get_chat_keyboard())
    else:
        await update.message.reply_text('خوش آمدید! برای پیوستن به چت، دکمه Join را فشار دهید.', reply_markup=get_join_keyboard())

async def join_chat(update: Update, context: CallbackContext) -> int:
    user_id = update.message.from_user.id
    if user_id not in chat_participants:
        await update.message.reply_text('لطفا نام مستعار خود را وارد کنید:')
        return CHAT_ALIAS
    else:
        await update.message.reply_text('شما قبلا به چت پیوسته‌اید.', reply_markup=get_chat_keyboard())
        return ConversationHandler.END

async def show_online_users(update: Update, context: CallbackContext) -> None:
    if online_users:
        users_list = list(online_users.values())
        random.shuffle(users_list)
        online_list = '\n'.join(users_list)
        await update.message.reply_text(f"کاربران آنلاین:\n{online_list}")
    else:
        await update.message.reply_text("هیچ کاربری آنلاین نیست.")

async def chat_alias(update: Update, context: CallbackContext) -> int:
    alias = update.message.text.strip()
    user_id = update.message.from_user.id

    if alias in user_aliases.values():
        await update.message.reply_text("این نام مستعار قبلا انتخاب شده است، لطفا نام مستعار دیگری انتخاب کنید:")
        return CHAT_ALIAS

    context.user_data['proposed_alias'] = alias
    await update.message.reply_text(f"نام مستعار شما '{alias}' خواهد بود. آیا آن را تایید می‌کنید؟ اگر خیر، 'تغییر نام' را انتخاب کنید.",
                                    reply_markup=get_confirm_keyboard())
    return ALIAS_CONFIRMATION

async def alias_confirmation(update: Update, context: CallbackContext) -> int:
    choice = update.message.text
    user_id = update.message.from_user.id

    if choice == "تایید":
        alias = context.user_data['proposed_alias']
        user_aliases[user_id] = alias
        chat_participants.add(user_id)
        online_users[user_id] = update.message.from_user.first_name
        join_message = f"<b>{alias}</b> به چت پیوست ."
        for participant in chat_participants:
            if participant != user_id:
                await context.bot.send_message(chat_id=participant, text=join_message , parse_mode='HTML')
        await update.message.reply_text(f"شما با نام مستعار <b>{alias}</b> به چت پیوستید.",parse_mode='HTML',
                                        reply_markup=get_chat_keyboard())
        return ConversationHandler.END
    elif choice == "تغییر نام":
        await update.message.reply_text("لطفا نام مستعار جدیدی وارد کنید:")
        return CHAT_ALIAS

async def handle_message(update: Update, context: CallbackContext) -> None:
    user_id = update.message.from_user.id
    if user_id in chat_participants:
        alias = user_aliases[user_id]  # گرفتن نام مستعار کاربر
        if update.message.text:  # اگر پیام حاوی متن است
            message = f"<b>{alias}:</b> {update.message.text}"
            for participant in chat_participants:
                if participant != user_id:
                    await context.bot.send_message(chat_id=participant, text=message, parse_mode='HTML')

async def leave_chat(update: Update, context: CallbackContext) -> None:
    user_id = update.message.from_user.id
    if user_id in chat_participants:
        alias = user_aliases.pop(user_id, None)
        chat_participants.remove(user_id)
        del online_users[user_id]
        leave_message = f"<b>{alias}</b> از چت خارج شد."
        for participant in chat_participants:
            await context.bot.send_message(chat_id=participant, text=leave_message ,parse_mode='HTML')
        await update.message.reply_text("شما از چت خارج شدید برای ورود join را انتخاب کنید." , reply_markup=get_join_keyboard())
    else :
       await update.message.reply_text("شما در هیچ چتی حضور ندارید" , reply_markup=get_join_keyboard())    

def main() -> None:
    application = Application.builder().token(Token).build()
    conv_handler = ConversationHandler(
    entry_points=[CommandHandler('start', start), CommandHandler('join', join_chat)],
    states={
        CHAT_ALIAS: [MessageHandler(filters.TEXT & ~filters.COMMAND, chat_alias)],
        ALIAS_CONFIRMATION: [MessageHandler(filters.TEXT & filters.Regex('^(تایید|تغییر نام)$'), alias_confirmation)]
    },
    fallbacks=[]
    )

    application.add_handler(conv_handler)
    application.add_handler(CommandHandler('join', join_chat))
    application.add_handler(CommandHandler('leave', leave_chat))
    application.add_handler(CommandHandler('show_online_users', show_online_users))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    application.run_polling()

if __name__ == '__main__':
    main()
