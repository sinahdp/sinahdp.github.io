a=int(input())
i=2
count=0
while (i<a/2):
    if(a%i == 0):
        count = 1
        break
    i=i+1    
if(count==0):
    print("prime")
else:
    print("not prime")