max_count = 0
max_a = 0
i = 1
def tedad_maghsom(a) :
    j=1
    count = 1
    while j <= a / 2 : 
        if(a % j == 0):
            count = count + 1
        j = j + 1
    return count
for i in range(20):
    a = int(input())
    tedad = tedad_maghsom(a)
    if(max_count < tedad) : 
        max_count = tedad
        max_a = a
    elif(max_count == tedad) :
        if(a > max_a):
            max_a = a
print(max_a , max_count)
