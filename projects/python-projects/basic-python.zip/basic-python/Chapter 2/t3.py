max=-100000
while 1:
    a = int(input())
    if(a == -1):
        break
    if(a>max):
        max = a
print(max)
