sum = 0
count = 0
for i in range(30):
    a = int(input())
    sum = sum + a
    if(a == 3):
        count = count + 1
    i=i+1
print(sum , count)
