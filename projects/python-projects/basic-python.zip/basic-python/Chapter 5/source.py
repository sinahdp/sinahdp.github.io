import csv
# For the average
from statistics import mean 

def calculate_averages(input_file_name, output_file_name):
    with open(input_file_name,"r") as file:
        reader = csv.reader(file)
        with open(output_file_name,"w",newline="") as outfile:
            writer = csv.writer(outfile)
            for row in reader:
                name = row[0]
                list = []
                for i in range(1,len(row)):
                    list.append(float(row[i]))
                writer.writerow([name , mean(list)])
def calculate_sorted_averages(input_file_name, output_file_name):
    with open(input_file_name,"r") as file:
        reader = csv.reader(file)
        with open(output_file_name,"w",newline="") as outfile:
            writer = csv.writer(outfile)
            mean_dict = dict()
            sorted_dict = dict()
            for row in reader:
                name = row[0]
                list = []
                for i in range(1,len(row)):
                    list.append(float(row[i]))
                mean_dict[name] = mean(list)
            sorted_dict = dict(sorted(mean_dict.items(),key=lambda item: (item[1],item[0])))
            for name in sorted_dict:
                writer.writerow([name,sorted_dict[name]])

def calculate_three_best(input_file_name, output_file_name):
    with open(input_file_name,"r") as file:
        reader = csv.reader(file)
        with open(output_file_name,"w",newline="") as outfile:
            writer = csv.writer(outfile)
            name_dict = dict()
            for row in reader:
                name = row[0]
                list = []
                for i in range(1,len(row)):
                    list.append(float(row[i]))
                name_dict[name] = mean(list)
            sorted_name = sorted(name_dict)
            best = [-10000000,-10000000,-10000000,]
            best_index = [-1,-1,-1]
            for name in sorted_name:
                if(name_dict[name] > best[0]):
                    best[2] = best[1]
                    best_index[2] = best_index[1]
                    best[1] = best[0]
                    best_index[1] = best_index[0]
                    best[0] = name_dict[name]
                    best_index[0] = name
                elif(name_dict[name] > best[1]):
                    best[2] = best[1]
                    best_index[2] = best_index[1]
                    best[1] = name_dict[name]
                    best_index[1] = name
                elif(name_dict[name] > best[2]):
                    best[2] = name_dict[name]
                    best_index[2] = name
            for i in range(3):
                writer.writerow([best_index[i] , name_dict[best_index[i]]])

def calculate_three_worst(input_file_name, output_file_name):
    with open(input_file_name,"r") as file:
        reader = csv.reader(file)
        with open(output_file_name,"w",newline="") as outfile:
            writer = csv.writer(outfile)
            mean_list = []
            for row in reader:
                list = []
                for i in range(1,len(row)):
                    list.append(float(row[i]))
                mean_list.append(mean(list))
            mean_list.sort()
            for i in range(3):
                writer.writerow([mean_list[i]])

def calculate_average_of_averages(input_file_name, output_file_name):
    with open(input_file_name,"r") as file:
        reader = csv.reader(file)
        with open(output_file_name,"w",newline="") as outfile:
            writer = csv.writer(outfile)
            mean_list = []
            for row in reader:
                list = []
                for i in range(1,len(row)):
                    list.append(float(row[i]))
                mean_list.append(mean(list))
            writer.writerow([mean(mean_list)])