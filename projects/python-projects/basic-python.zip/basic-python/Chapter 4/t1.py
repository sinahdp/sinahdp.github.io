import math
count = int(input())
list = []
for i in range(count):
    number = int(input())
    list.append("{:.15f}".format(math.sqrt(number)))
for item in list:
    string = str(item)
    print(string[:-11])