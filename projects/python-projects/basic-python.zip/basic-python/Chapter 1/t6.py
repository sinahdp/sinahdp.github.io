a=int(input())
if (0<=a & a<6):
    print("khordsal")
elif (6<=a & a<10):
    print("koodak")
elif (10<=a & a<14):
    print("nojavan")
elif (14<=a & a<24):
    print("javan")
elif (24<=a & a<40):
    print("bozorgsal")
elif (40<=a):
    print("miansal")