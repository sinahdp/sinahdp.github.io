x=int(input())
f1=x%10
x=x//10
f2=x%10
x=x//10
x=f1*100+f2*10+x
print(x*2)