x=int(input())
x=x//10
print(x*10+10)