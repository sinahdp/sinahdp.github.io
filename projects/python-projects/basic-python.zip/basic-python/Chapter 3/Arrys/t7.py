arr = input()
check1 = 1
check2 = 1
index1 = "/"
index2  = "/"
result="NO"
def myfunc2(str,k):
    if (str[k+2] == "/"):
        return int(str[k+1])
    else:
        return int(str[k+1])*10 + int(str[k+2])

def myfunc1(index1,index2):
    for i in range(len(index1)-2):
        if index1[i] == "/":
            x1 = myfunc2(index1,i)
            for j in range(len(index2)-2):
                if index2[j] == "/":
                    x2 = myfunc2(index2,j)
                    if(abs(x1-x2) > 1):
                        return "YES"
    return "NO"
for i in range(len(arr) - 1):
    s = arr[i] + arr[i+1]
    if(s == "AB"):
        index1 = index1 + str(i) + "/"
        check1 = 0
    if(s == "BA"):
        index2 = index2 + str(i) + "/"
        check2 = 0
if((check1 + check2) == 0):
    print(myfunc1(index1,index2))
else:
    print("NO")