s = input()
def sort(arr):
    for i in range(len(arr)):
        if(arr[i] == "+"):
            continue
        else:
            cursor = arr[i]
            pos = i
            while pos > 0 and arr[pos-2] > cursor:
                arr = arr[:pos] + arr[pos-2] + arr[pos+1:]
                pos = pos - 2
            arr = arr[:pos] + cursor + arr[pos+1:]
    return arr
s = sort(s)
print(s)