a = input()
a = a.lower()
s = ['a','e','i','o','u']
for i in a :
    check=0
    for j in s :
        if(i == j) :
            z = a.find(j) 
            a = a[:z] + a[z+1:]
            break
def dot(a):
    str = ""
    for i in range(len(a)):
        str = str + '.' + a[i]
    return str
print(dot(a))