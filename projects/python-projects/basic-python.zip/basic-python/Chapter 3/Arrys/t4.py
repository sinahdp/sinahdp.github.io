arr = input()
word = "hello"
j = 0
for i in range(len(arr)):
    if(arr[i] == word[j]):
        j = j + 1
    if(j==len(word)):
        break
if(j==5):
    print("YES")
else:
    print("NO")