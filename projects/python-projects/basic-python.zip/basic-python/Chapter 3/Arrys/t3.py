source = ""
num = ""
for i in range (10):
    arr = input()
    source = source + arr[0].upper() + arr[1:].lower()
    num = num + "/" + str(len(arr))
num = num + "/"
def myfunction (source,num):
    s = 0
    for i in range(len(num)-2):
        if num[i] == "/":
            index = s
            if (num[i+2] == "/"):
                s = s + int(num[i+1])
            else:
                k = int(num[i+1])*10 + int(num[i+2])
                s = s + k
            print(source[index:s])
myfunction(source,num)
