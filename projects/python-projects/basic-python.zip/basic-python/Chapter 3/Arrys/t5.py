arr = input()
check = 0
for i in range(len(arr)):
    if(ord("a") <= ord(arr[i]) <= ord("z")):
        check = check + 1
    else:
        check = check - 1
if(check >= 0):
    print(arr.lower())
else:
    print(arr.upper())