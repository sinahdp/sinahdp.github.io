arr = input()
arr = arr.lower()
len = len(arr)
check = 1
if(len % 2 == 1):
    x1 = len // 2 - 1
    x2 = len // 2 + 1
    while(x1 != -1):
        if(arr[x1] != arr[x2]):
            check = 0
            break
        x1 = x1 -1
        x2 = x2 + 1
if(len % 2 == 0):
    x1 = len // 2 - 1
    x2 = len // 2
    while(x1 != -1):
        if(arr[x1] != arr[x2]):
            check = 0
            break
        x1 = x1 - 1
        x2 = x2 + 1
if(check == 1):
    print("palindrome")
else:
    print("not palindrome")
