count = int(input())
list = []
items = input()
list = items.split()
i = 0
while(i < len(list)):
    if(int(list[i]) > 2):
        del list[i]
        i = i - 1
    else:
        i = i + 1
print(len(list) // 3)