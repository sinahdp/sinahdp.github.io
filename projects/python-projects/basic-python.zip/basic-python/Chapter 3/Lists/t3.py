count = int(input())
list = []
source = ""
for i in range(count):
    arr = input()
    source = source + arr + " "
list = source.split()
def myfunc():
    i = 0
    while(i < (count * 2 - 3)):
        j = i + 2
        while(j < (count * 2 - 1)):
            if(int(list[i]) > int(list[j]) and int(list[i+1]) < int(list[j+1])):
                return 1
            if(int(list[i]) < int(list[j]) and int(list[i+1]) > int(list[j+1])):
                return 1
            j = j + 2
        i = i + 2
    return 0
if(myfunc()):
    print("happy irsa")
else:
    print("poor irsa")