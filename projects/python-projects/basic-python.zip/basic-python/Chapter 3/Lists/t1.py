list = []
items = input()
list = items.split()
for i in range(len(list)):
    list[i]=int(list[i])
print(max(list)-min(list))
