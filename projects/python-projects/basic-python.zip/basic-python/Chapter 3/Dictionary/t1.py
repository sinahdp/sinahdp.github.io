count = int(input())
citys = dict()
for i in range(count):
    city = input()
    citys[city] = citys.get(city,0) + 1
sorted_keys = sorted(citys)
print(sorted_keys)
for city in sorted_keys:
    print(city,citys[city])
 