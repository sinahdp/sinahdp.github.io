count = int(input())
dic = dict()
for i in range(count):
    key_value = input()
    container = key_value.split()
    dic[container[0]] = container[1]
text = input()
list_text = text.split()
for i in range(len(list_text)):
    if(list_text[i] in dic):
        list_text[i]=dic[list_text[i]]
print(" ".join(list_text))